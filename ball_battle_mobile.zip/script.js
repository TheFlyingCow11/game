const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

class Player {
  constructor(x, y, color) {
    this.x = x;
    this.y = y;
    this.radius = 30;
    this.color = color;
    this.hitCount = 0;
  }

  draw() {
    ctx.beginPath();
    ctx.fillStyle = this.color;
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  isHitBy(projectile) {
    const dx = this.x - projectile.x;
    const dy = this.y - projectile.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    return dist < this.radius + projectile.radius;
  }
}

class Projectile {
  constructor(x, y, vx, vy) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.radius = 10;
  }

  move() {
    this.x += this.vx;
    this.y += this.vy;
  }

  draw() {
    ctx.beginPath();
    ctx.fillStyle = "orange";
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fill();
  }
}

let p1 = new Player(100, canvas.height / 2, "red");
let p2 = new Player(canvas.width - 100, canvas.height / 2, "green");
let projectiles = [];
let orbs = [];

function spawnOrb() {
  const x = Math.random() * canvas.width * 0.8 + canvas.width * 0.1;
  const y = Math.random() * canvas.height * 0.8 + canvas.height * 0.1;
  orbs.push({ x, y, radius: 15 });
}
setInterval(spawnOrb, 2000);

function shoot(from, to) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const mag = Math.sqrt(dx * dx + dy * dy);
  const speed = 7;
  const vx = (dx / mag) * speed;
  const vy = (dy / mag) * speed;
  projectiles.push(new Projectile(from.x, from.y, vx, vy));
}

let joyLeft = { x: 0, y: 0 };
let joyRight = { x: 0, y: 0 };

function setupJoystick(areaId, callback) {
  const area = document.getElementById(areaId);
  let startX = 0, startY = 0;

  area.addEventListener("touchstart", e => {
    const t = e.touches[0];
    startX = t.clientX;
    startY = t.clientY;
  });

  area.addEventListener("touchmove", e => {
    e.preventDefault();
    const t = e.touches[0];
    const dx = t.clientX - startX;
    const dy = t.clientY - startY;
    const mag = Math.sqrt(dx * dx + dy * dy);
    if (mag > 50) {
      dx *= 50 / mag;
      dy *= 50 / mag;
    }
    callback({ x: dx / 50, y: dy / 50 });
  });

  area.addEventListener("touchend", () => {
    callback({ x: 0, y: 0 });
  });
}

setupJoystick("joystick-left", data => joyLeft = data);
setupJoystick("joystick-right", data => joyRight = data);

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  p1.x += joyLeft.x * 5;
  p1.y += joyLeft.y * 5;
  p2.x += joyRight.x * 5;
  p2.y += joyRight.y * 5;

  for (let p of [p1, p2]) {
    p.x = Math.max(p.radius, Math.min(canvas.width - p.radius, p.x));
    p.y = Math.max(p.radius, Math.min(canvas.height - p.radius, p.y));
  }

  p1.draw();
  p2.draw();

  for (let i = orbs.length - 1; i >= 0; i--) {
    const orb = orbs[i];
    ctx.beginPath();
    ctx.fillStyle = "orange";
    ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
    ctx.fill();

    for (let player of [p1, p2]) {
      const dx = orb.x - player.x;
      const dy = orb.y - player.y;
      if (Math.sqrt(dx * dx + dy * dy) < orb.radius + player.radius) {
        const target = player === p1 ? p2 : p1;
        shoot(player, target);
        orbs.splice(i, 1);
        break;
      }
    }
  }

  for (let i = projectiles.length - 1; i >= 0; i--) {
    const proj = projectiles[i];
    proj.move();
    proj.draw();

    for (let player of [p1, p2]) {
      if (player.isHitBy(proj)) {
        player.hitCount++;
        projectiles.splice(i, 1);
        break;
      }
    }
  }

  if (p1.hitCount >= 3) {
    alert("הירוק ניצח!");
    document.location.reload();
  } else if (p2.hitCount >= 3) {
    alert("האדום ניצח!");
    document.location.reload();
  }

  requestAnimationFrame(gameLoop);
}

gameLoop();
